#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(int argc, string argv[]){
    if (argc != 2 ){
        printf ("Usage: ./caesar key\n");
        return 1;
    }
    int lengthofArgv = strlen(argv[1]);
    for (int i = 0; i < lengthofArgv; i++){
        if (!(isdigit(argv[1][i]))){
            printf("Usage: ./caesar key \n");
            return 1;
        }
    }
    int k = atoi(argv[1]);

    if(k<0){
        printf ("Usage: ./caesar key \n");
        return 1;
    }

    string text = get_string("plaintext: ");
    printf("ciphertext: ");
    int length = strlen(text);
    for (int i = 0; i < length ; i++){
        char let = text[i];
        if(isalpha(let)){
            if(islower(let)){
                char cLet1 = ((let-97+k) % 26) + 97;
                printf("%c", cLet1);
            }
            else if (isupper(let)){
                char cLet2 = ((let-65+k) % 26) + 65;
                printf("%c", cLet2);
            }
        }
        else{
            printf("%c", let);
        }

    }
    printf("\n");
}
