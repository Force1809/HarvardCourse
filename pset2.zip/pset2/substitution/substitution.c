#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool validate(string s);

int main (int argc, string argv[]){
    if (argc != 2 ){
        printf ("Usage: ./substitution key\n");
        return 1;
    }
    if(!validate(argv[1])){
        printf ("Usage: ./substitution key\n");
        return 1;
    }
    string text = get_string("plaintext: ");
    int length = strlen(text);
    string key = argv[1];
    for (int i= 'A'; i< 'Z'; i++){
        key[i-'A'] = toupper(key[i-'A'])-i;
    }
    printf("ciphertext: ");
    for (int i = 0; i < length ; i++){
        char let = text[i];
        if(isalpha(let)){
            let = let + key[let-(isupper(let) ? 'A': 'a')];
            printf("%c", let);
        }
        else{
            printf("%c", let);
        }
    }
    printf("\n");
}

bool validate(string s){

    int len = strlen(s);
    for (int i = 0; i < len; i++)
    {
        if (!isalpha(s[i]))
        {
           return false;
        }
    }
    if (len!=26)
    {
        return false;;
    }
    int counter = 0;
    for (int i = 0; i < len; i++)
    {
        for (int j = 0; j<len; j++)
        {
            if (s[j] == s[i])
            {
                counter++;
            }
        }
    }
    if (counter != len)
    {
        return false;
    }
    return true;
}

