#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <math.h>

int countLetters(string text);
int countWords(string text);
int countSentences(string text);
float getGrade(int letters, int sentences, int words);

int main (void){
    string text = get_string("Text: ");
    int numLetters = countLetters(text);
    int numWords = countWords(text);
    int numSentences = countSentences(text);
    float gradeIndex = getGrade(numLetters, numSentences, numWords);
    //printf("%i letter(s)\n", numLetters);
    //printf("%i word(s)\n", numWords);
    //printf("%i sentence(s)\n", numSentences);
    if (gradeIndex >= 16){
        printf("Grade 16+\n");
    }
    else if(gradeIndex < 1){
        printf("Before Grade 1\n");
    }
    else{
        printf("Grade %.0f\n", gradeIndex);
    }

}

int countLetters(string text){
    int letters= 0;
    int length = strlen(text);
    for (int i = 0; i<length ; i++){
        if ((text[i] >= 65 && text[i] <= 90) || (text[i] >= 97 && text[i] <= 122)){
             letters++;
            }
        }
    return letters;
}

int countWords(string text){
    int words = 1;
    int length = strlen(text);
    for (int i = 0; i<length ; i++){
        if (text[i] == ' '){
            words++;
        }
    }
    return words;
}

int countSentences(string text){
    int sentences = 0;
    int length = strlen(text);
    for (int i = 0;i<length;i++){
        if (text[i] == '.' || text[i] == '!' || text[i] == '?'){
            sentences++;
        }
    }
    return sentences;
}

float getGrade(int letters, int sentences, int words){
    float L = (letters * 100) / words;
    float S = (sentences * 100) / words;
    float index = 0.0588 * L - 0.296 * S - 15.8;
    return round(index);
}