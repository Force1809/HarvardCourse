# TODO
import csv
import sys
import sqlite3
from cs50 import SQL

def partition_name(full_name):
    names = full_name.split()
    return names if len(names) >= 3 else [names[0], None, names[1]]

def main():
    if (len(sys.argv) !=2):
        sys.exit(1)
        
    fname = sys.argv[1]
    
    if not (fname.endswith(".csv")):
        sys.exit("You must provide a *.csv")
    
    db = SQL("sqlite:///students.db")
    
    with open(fname, "r") as names:
        reader = csv.DictReader(names)
        
        for row in reader:
            names = partition_name(row["name"])
            db.execute("INSERT INTO students(first, middle, last, house, birth) VALUES(?, ?, ?, ?, ?)",
                names[0], names[1], names[2], row["house"], row["birth"]
            )


if __name__ == "__main__":
    main()
            
        
