# TODO
import csv
import sys
import sqlite3
from cs50 import SQL

def main():
    if(len(sys.argv)!=2):
        sys.exit(1)
    
    hname = sys.argv[1]

    db = SQL("sqlite:///students.db")
    
    rows = db.execute("SELECT * FROM students WHERE house = ? ORDER BY last, first", hname)
    
    for row in rows:
        first, middle, last, birth = row["first"], row["middle"], row["last"], row["birth"]
        print(f"{first} {middle + ' ' if middle else ''}{last}, born {birth}")

if __name__ == "__main__":
    main()
            
           
    