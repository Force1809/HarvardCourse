from cs50 import get_string

def main():
    txt = get_string("Text: ")
    words = 1
    for i in range(len(txt)):
        if txt[i]== " ":
            words+=1
            
    letters = 0
    for i in range(len(txt)):
        if txt[i].isalpha():
             letters+=1
             
    sentences = 0
    for i in range(len(txt)):
        if txt[i]== "." or txt[i]=="!" or txt[i]=="?":
            sentences +=1
            
    L = (letters*100)/words
    S = (sentences*100)/words
   

    index = round(0.0588 * L - 0.296 * S - 15.8)
    if index>=16:
        print("Grade 16+")
    elif index < 1:
        print("Before Grade 1")
    else:
        print("Grade ", index)


main()