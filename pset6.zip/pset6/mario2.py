from cs50 import get_int

def main():
    row = 1
    while True:
        height = get_int("Height: ")
        if height>=1 and height<=8:
            break
    
    while height>0:
        print(" "*(height-1), end = "")
        print("#"*row)
        row+=1
        height-=1

main()