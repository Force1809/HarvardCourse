from cs50 import get_float

def main():
    counter = 0
    while True:
        change = get_float("Change owed: ")
        if change > 0:
            break
    total = round(change*100)
    while total > 0:
        if total - 25 >= 0:
            total = total - 25
            counter += 1
        elif total - 10 >= 0:
            total = total - 10
            counter += 1
        elif total - 5 >= 0:
            total = total - 5
            counter +=1
        else:
            total = total - 1
            counter +=1
            
    print (counter)
    
main()