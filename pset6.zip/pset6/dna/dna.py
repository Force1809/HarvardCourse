from sys import argv, exit
import csv

def getMax(large, sub):
    ans = [0] * len(large)
    for i in range(len(large) - len(sub), -1, -1):
        if large[i:i+len(sub)]== sub:
            if len(large) -1 < len(sub)+i:
                ans[i] = 1
            else:
                ans[i] = 1+ans[i+len(sub)]
        
    return max(ans)

def print_match(reader, actual):
    for line in reader:
        person = line[0]
        values = [int(val) for val in line[1:]]
        if values == actual:
            print(person)
            return
    print("No Match")
def main():
    if len(argv)!=3:
        print("Please enter correct amount of command-line arguements")
        exit(1)
    pathV = argv[1]
    with open(pathV) as csv_file:
        reader = csv.reader(csv_file)
        all_seqs = next(reader)[1:]
        textV = argv[2]
        with open(textV) as txt_file:
            txtV = txt_file.read()
            actual = [getMax(txtV, seq) for seq in all_seqs]
       
        print_match(reader, actual)

if __name__ == "__main__":
    main()