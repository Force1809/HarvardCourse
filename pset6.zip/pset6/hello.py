from cs50 import get_string

def main():
    name = get_string("What is your name?\n")
    print(f"Hello, {name}")

main()